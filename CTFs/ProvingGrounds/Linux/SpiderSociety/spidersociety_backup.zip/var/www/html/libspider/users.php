<?php
$users = [
    "admin" => "admin"
];
?>
